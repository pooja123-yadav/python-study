"""
Context Managers in Python

A context manager is a Python object that provides a way to manage resources properly, 
ensuring proper acquisition and release of resources like:
- File operations
- Database connections
- Network connections
- Threading locks
- etc.

The main benefits of using context managers:
1. Automatic resource management
2. Clean code and better readability
3. Guaranteed cleanup of resources
4. Exception handling built-in

Context Managers: 

Context managers are typically used for resource management, such as opening and closing files, acquiring and releasing locks, or managing database connections

How Context Managers Work?
A context manager is an object that implements the context management protocol, which consists of two methods:
__enter__(): This method is executed when the execution flow enters the context of the with statement. It can return a value that is assigned to the variable after the as keyword.
__exit__(exc_type, exc_value, traceback): This method is executed when the execution flow leaves the context of the with statement. It can handle exceptions if they occur within the block.

Custom Context Manager
You can create your own context manager by defining a class with __enter__ and __exit__ methods:
class MyContextManager:
    def __enter__(self):
        print(""Entering the context"")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        print(""Exiting the context"")

# Usage
with MyContextManager() as manager:
    print(""Inside the context"")

They are particularly useful in scenarios where resources need to be managed carefully, such as file I/O, network connections, and concurrency control.

"""

# 1. Using context manager with 'with' statement for file handling
def file_handling_example():
    # Traditional way (without context manager)
    file = open('example.txt', 'w')
    try:
        file.write('Hello World')
    finally:
        file.close()
    
    # Using context manager (with statement)
    with open('example.txt', 'w') as file:
        file.write('Hello World')
        # File automatically closes after the block

# 2. Creating a custom context manager using class
class DatabaseConnection:
    def __init__(self, host, user, password):
        self.host = host
        self.user = user
        self.password = password
    
    def __enter__(self):
        print(f"Connecting to database at {self.host}")
        # Setup database connection here
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        print("Closing database connection")
        # Close database connection here
        if exc_type is not None:
            print(f"An error occurred: {exc_value}")
        return False  # False means exceptions are re-raised

# 3. Creating a context manager using contextlib.contextmanager decorator
from contextlib import contextmanager
import time

@contextmanager
def timer():
    start = time.time()
    yield  # This is where the with block's contents will run
    end = time.time()
    print(f"Elapsed time: {end - start:.2f} seconds")

# Example usage of custom context managers
def main():
    # Using the DatabaseConnection context manager
    with DatabaseConnection("localhost", "user", "password") as db:
        print("Performing database operations")
        # Database operations here
    
    # Using the timer context manager
    with timer():
        # Some time-consuming operation
        time.sleep(1)
        print("Performing some task")

# 4. Context manager for thread locks
from threading import Lock

def thread_safe_operation():
    lock = Lock()
    with lock:
        # Critical section - only one thread can execute this at a time
        print("Thread-safe operation")

# 5. Multiple context managers
def multiple_context_managers():
    with open('input.txt') as input_file, open('output.txt', 'w') as output_file:
        content = input_file.read()
        output_file.write(content.upper())

if __name__ == "__main__":
    main()