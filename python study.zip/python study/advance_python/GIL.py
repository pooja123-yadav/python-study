"""
Global Interpreter Lock (GIL) in Python

What is GIL?
- GIL is a mutex (lock) that protects access to Python objects
- Allows only one thread to execute Python bytecode at a time
- Present in CPython (the reference implementation of Python)

Why GIL exists?
1. Memory Management: Simplifies Python's memory management by preventing race conditions
2. Reference Counting: Makes Python's reference counting thread-safe
3. Legacy Reasons: Historical design decision that helped early Python development
"""

import threading
import time
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

# Demonstration of GIL's impact on CPU-bound tasks
def cpu_bound_task(n):
    """A CPU-intensive task that performs calculations"""
    count = 0
    for i in range(n):
        count += i
    return count

# Demonstration of GIL's impact on IO-bound tasks
def io_bound_task(seconds):
    """An IO-bound task that mainly waits"""
    time.sleep(seconds)
    return f"Slept for {seconds} seconds"

def demonstrate_gil_cpu_bound():
    """Shows how GIL affects CPU-bound operations"""
    print("\n=== CPU-Bound Task Performance ===")
    
    # Single-threaded execution
    start = time.time()
    results = [cpu_bound_task(10**7) for _ in range(4)]
    print(f"Sequential execution time: {time.time() - start:.2f} seconds")
    
    # Multi-threaded execution (limited by GIL)
    start = time.time()
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(cpu_bound_task, [10**7] * 4))
    print(f"Thread Pool execution time: {time.time() - start:.2f} seconds")
    
    # Multi-process execution (bypasses GIL)
    start = time.time()
    with ProcessPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(cpu_bound_task, [10**7] * 4))
    print(f"Process Pool execution time: {time.time() - start:.2f} seconds")

def demonstrate_gil_io_bound():
    """Shows how GIL doesn't affect IO-bound operations"""
    print("\n=== IO-Bound Task Performance ===")
    
    # Single-threaded execution
    start = time.time()
    results = [io_bound_task(1) for _ in range(4)]
    print(f"Sequential execution time: {time.time() - start:.2f} seconds")
    
    # Multi-threaded execution (works well despite GIL)
    start = time.time()
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(io_bound_task, [1] * 4))
    print(f"Thread Pool execution time: {time.time() - start:.2f} seconds")

"""
Limitations of GIL:

1. CPU-Bound Performance:
   - Cannot utilize multiple CPU cores for CPU-intensive tasks
   - Multi-threaded Python code may run slower than sequential code

2. Multi-Core Usage:
   - Single Python process can only run on one CPU core at a time
   - Doesn't take full advantage of modern multi-core processors

3. Complex Threading:
   - Makes multi-threaded programming less effective for CPU-bound tasks
   - Can cause thread contention and switching overhead

Solutions to GIL Limitations:

1. Use multiprocessing instead of threading for CPU-bound tasks
2. Use async/await for IO-bound tasks
3. Use alternative Python implementations (Jython, IronPython)
4. Use C extensions that release the GIL
"""

def show_gil_workarounds():
    """Demonstrates common workarounds for GIL limitations"""
    print("\n=== GIL Workarounds ===")
    
    # 1. Using multiprocessing for CPU-bound tasks
    def multiprocessing_example():
        with ProcessPoolExecutor(max_workers=4) as executor:
            return list(executor.map(cpu_bound_task, [10**6] * 4))
    
    # 2. Using threading for IO-bound tasks
    def threading_example():
        with ThreadPoolExecutor(max_workers=4) as executor:
            return list(executor.map(io_bound_task, [0.1] * 4))

if __name__ == "__main__":
    print("Demonstrating GIL's impact on different types of tasks...")
    demonstrate_gil_cpu_bound()
    demonstrate_gil_io_bound()

"""
Key Points to Remember:

1. GIL Impact:
   - Affects CPU-bound tasks significantly
   - Minimal impact on IO-bound tasks
   - No impact on multiprocessing

2. When to Worry About GIL:
   - CPU-intensive operations
   - Need for true parallelism
   - High-performance computing requirements

3. When GIL Isn't a Problem:
   - IO-bound applications
   - Single-threaded applications
   - Web applications (typically IO-bound)

4. Best Practices:
   - Use multiprocessing for CPU-bound tasks
   - Use threading for IO-bound tasks
   - Use async/await for modern IO-bound operations
   - Consider C extensions for performance-critical code
"""
