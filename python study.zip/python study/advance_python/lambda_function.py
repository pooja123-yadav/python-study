"""
Lambda Functions in Python?

Lambda functions (also called anonymous functions) are small, one-time-use functions
that can have any number of arguments but can only have one expression.

Syntax:
lambda arguments: expression

Key characteristics:
1. Anonymous - no explicit name
2. Single expression only
3. Can be used as function objects
4. Ideal for short operations
5. Commonly used with map(), filter(), and reduce()
"""

# 1. Basic Lambda Function Examples
def basic_lambda_examples():
    # Traditional function
    def square(x): 
        return x ** 2
    
    # Equivalent lambda function
    square_lambda = lambda x: x ** 2
    
    # Multiple arguments
    sum_lambda = lambda a, b: a + b
    
    print("Square using lambda:", square_lambda(5))  # Output: 25
    print("Sum using lambda:", sum_lambda(3, 4))     # Output: 7

# 2. Lambda with Built-in Higher-Order Functions
def lambda_with_builtin_functions():
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    # Using map() with lambda
    squares = list(map(lambda x: x**2, numbers))
    print("Mapped squares:", squares)
    
    # Using filter() with lambda
    even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
    print("Filtered even numbers:", even_numbers)
    
    # Using reduce() with lambda
    from functools import reduce
    sum_all = reduce(lambda x, y: x + y, numbers)
    print("Reduced sum:", sum_all)

# 3. Lambda in Sorting
def lambda_in_sorting():
    # List of tuples (name, age)
    people = [
        ('Alice', 25),
        ('Bob', 30),
        ('Charlie', 20),
        ('David', 35)
    ]
    
    # Sort by age
    sorted_by_age = sorted(people, key=lambda x: x[1])
    print("Sorted by age:", sorted_by_age)
    
    # Sort by name
    sorted_by_name = sorted(people, key=lambda x: x[0])
    print("Sorted by name:", sorted_by_name)

# 4. Lambda in List Comprehension Alternative
def lambda_list_operations():
    numbers = [1, 2, 3, 4, 5]
    
    # Using map instead of list comprehension
    squares = list(map(lambda x: x**2, numbers))
    
    # Conditional mapping
    conditional_squares = list(map(
        lambda x: x**2 if x % 2 == 0 else x,
        numbers
    ))
    
    print("Squares:", squares)
    print("Conditional squares:", conditional_squares)

# 5. Lambda as Function Arguments
def apply_operation(x, operation):
    return operation(x)

def lambda_as_arguments():
    # Passing lambda as argument
    result1 = apply_operation(5, lambda x: x * 2)
    result2 = apply_operation(5, lambda x: x ** 2)
    
    print("Double:", result1)
    print("Square:", result2)

# 6. Lambda in Functional Programming
def functional_programming_examples():
    # Composition of functions using lambda
    compose = lambda f, g: lambda x: f(g(x))
    
    # Example functions
    double = lambda x: x * 2
    increment = lambda x: x + 1
    
    # Compose functions
    double_then_increment = compose(increment, double)
    increment_then_double = compose(double, increment)
    
    print("Double then increment:", double_then_increment(5))  # (5*2)+1 = 11
    print("Increment then double:", increment_then_double(5))  # (5+1)*2 = 12

"""
Map, Filter, and Reduce in Python

These are built-in functions used for functional programming:

1. map(): Applies a function to every item in an input list
2. filter(): Creates a list of elements for which a function returns True
3. reduce(): Applies a function of two arguments cumulatively to the items of a sequence
"""

# Adding these examples to our existing lambda_function.py file

def map_examples():
    """
    map(function, iterable, ...)
    Returns a map object that can be converted to list, tuple etc.
    """
    numbers = [1, 2, 3, 4, 5]
    
    # Example 1: Using map with lambda
    squares = list(map(lambda x: x**2, numbers))
    print("Squares using map:", squares)  # Output: [1, 4, 9, 16, 25]
    
    # Example 2: Map with multiple iterables
    list1 = [1, 2, 3]
    list2 = [10, 20, 30]
    sums = list(map(lambda x, y: x + y, list1, list2))
    print("Sum of two lists:", sums)  # Output: [11, 22, 33]
    
    # Example 3: Map with regular function
    def celsius_to_fahrenheit(c):
        return (9/5) * c + 32
    
    temperatures_c = [0, 10, 20, 30]
    temperatures_f = list(map(celsius_to_fahrenheit, temperatures_c))
    print("Temperatures in Fahrenheit:", temperatures_f)

def filter_examples():
    """
    filter(function, iterable)
    Returns a filter object containing elements for which function returns True
    """
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    # Example 1: Filter even numbers
    even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
    print("Even numbers:", even_numbers)  # Output: [2, 4, 6, 8, 10]
    
    # Example 2: Filter with regular function
    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True
    
    prime_numbers = list(filter(is_prime, range(1, 20)))
    print("Prime numbers:", prime_numbers)  # Output: [2, 3, 5, 7, 11, 13, 17, 19]
    
    # Example 3: Filter non-empty strings
    strings = ['', 'Hello', '', 'World', '  ', 'Python']
    non_empty = list(filter(None, strings))  # None removes empty strings
    print("Non-empty strings:", non_empty)

def reduce_examples():
    """
    reduce(function, sequence[, initial])
    Applies function of two arguments cumulatively to the items of sequence
    """
    from functools import reduce
    
    numbers = [1, 2, 3, 4, 5]
    
    # Example 1: Sum of all numbers
    sum_all = reduce(lambda x, y: x + y, numbers)
    print("Sum using reduce:", sum_all)  # Output: 15
    
    # Example 2: Product of all numbers
    product = reduce(lambda x, y: x * y, numbers)
    print("Product using reduce:", product)  # Output: 120
    
    # Example 3: Reduce with initial value
    numbers_with_initial = reduce(lambda x, y: x + y, numbers, 10)
    print("Sum with initial value:", numbers_with_initial)  # Output: 25
    
    # Example 4: More complex reduce
    def max_length_string(s1, s2):
        return s1 if len(s1) >= len(s2) else s2
    
    words = ['python', 'programming', 'functional', 'is', 'awesome']
    longest_word = reduce(max_length_string, words)
    print("Longest word:", longest_word)

def practical_examples():
    """Real-world examples combining map, filter, and reduce"""
    
    # Example 1: Calculate average of even numbers
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    from functools import reduce
    
    average = reduce(lambda x, y: x + y,
                    filter(lambda x: x % 2 == 0, numbers)) / \
             len(list(filter(lambda x: x % 2 == 0, numbers)))
    print("Average of even numbers:", average)
    
    # Example 2: Convert temperatures and filter above freezing
    celsius = [0, -10, 15, 20, -5, 30]
    above_freezing_f = list(
        filter(lambda x: x > 32,
               map(lambda c: (9/5) * c + 32, celsius))
    )
    print("Temperatures above freezing (F):", above_freezing_f)

"""
Memory Efficiency in Map, Filter, and Reduce

These functions are memory efficient because:
1. They are iterator-based (lazy evaluation)
2. They process elements one at a time
3. They don't create intermediate lists unless explicitly converted
"""

def memory_efficiency_examples():
    # Let's demonstrate memory efficiency with examples
    
    # 1. Memory Efficiency in Map
    def demonstrate_map_efficiency():
        numbers = range(1, 1000000)  # Creates a range object, not a list
        
        # Memory efficient - creates iterator
        squared_iterator = map(lambda x: x**2, numbers)
        
        # Memory inefficient - creates full list
        squared_list = [x**2 for x in numbers]
        
        # Accessing first few elements of map
        print("First 5 squared numbers (iterator):")
        for i, num in enumerate(squared_iterator):
            if i >= 5:
                break
            print(num)
    
    # 2. Memory Efficiency in Filter
    def demonstrate_filter_efficiency():
        numbers = range(1, 1000000)
        
        # Memory efficient - creates iterator
        even_iterator = filter(lambda x: x % 2 == 0, numbers)
        
        # Memory inefficient - creates full list
        even_list = [x for x in numbers if x % 2 == 0]
        
        print("\nFirst 5 even numbers (iterator):")
        for i, num in enumerate(even_iterator):
            if i >= 5:
                break
            print(num)
    
    # 3. Comparing Memory Usage
    def compare_memory_usage():
        from sys import getsizeof
        numbers = range(1000000)
        
        # Iterator-based operations
        mapped = map(lambda x: x**2, numbers)
        filtered = filter(lambda x: x % 2 == 0, numbers)
        
        # List-based operations
        mapped_list = [x**2 for x in numbers]
        filtered_list = [x for x in numbers if x % 2 == 0]
        
        print("\nMemory Usage Comparison:")
        print(f"map object size: {getsizeof(mapped)} bytes")
        print(f"filter object size: {getsizeof(filtered)} bytes")
        print(f"mapped list size: {getsizeof(mapped_list)} bytes")
        print(f"filtered list size: {getsizeof(filtered_list)} bytes")
    
    # 4. Chaining Operations Efficiently
    def demonstrate_chaining():
        numbers = range(1, 1000000)
        
        # Memory efficient - all operations stay as iterators
        result_iterator = map(
            lambda x: x**2,
            filter(lambda x: x % 2 == 0, numbers)
        )
        
        print("\nFirst 5 squared even numbers (chained iterators):")
        for i, num in enumerate(result_iterator):
            if i >= 5:
                break
            print(num)
    
    # Run all demonstrations
    demonstrate_map_efficiency()
    demonstrate_filter_efficiency()
    compare_memory_usage()
    demonstrate_chaining()

def explain_iterator_processing():
    """
    Demonstrating how map/filter process and track elements
    """
    numbers = [1, 2, 3, 4, 5]
    
    # Create map iterator
    squared_map = map(lambda x: x**2, numbers)
    
    print("Understanding iterator processing:")
    
    # 1. Iterator maintains position but doesn't store processed values
    print("\nFirst iteration:")
    for num in squared_map:
        print(f"Processing: {num}")
    
    print("\nSecond iteration (nothing prints - iterator exhausted):")
    for num in squared_map:  # Nothing prints - iterator is exhausted
        print(f"Processing: {num}")
    
    # 2. When converting to list, Python:
    # - Creates a new empty list
    # - Iterates through the map object once
    # - Stores each processed value in the list
    squared_map = map(lambda x: x**2, numbers)  # Create new iterator
    squared_list = list(squared_map)  # Converts all at once
    print(f"\nConverted to list: {squared_list}")

def demonstrate_iterator_limitation():
    """
    Demonstrating how iterators can only be used once and need to be recreated
    """
    numbers = [1, 2, 3, 4, 5]
    
    # Create map iterator
    squared_numbers = map(lambda x: x**2, numbers)
    
    print("First iteration:")
    for num in squared_numbers:
        print(num)
    
    print("\nSecond iteration (nothing prints - iterator is exhausted):")
    for num in squared_numbers:  # Nothing will print - iterator is exhausted
        print(num)
    
    print("\nTo use again, need to create new iterator:")
    # Create new iterator
    squared_numbers = map(lambda x: x**2, numbers)
    for num in squared_numbers:
        print(num)

    # If you need multiple uses, convert to list (but loses memory efficiency)
    squared_list = list(map(lambda x: x**2, numbers))
    print("\nUsing list - can iterate multiple times:")
    print("First time:", squared_list)
    print("Second time:", squared_list)

if __name__ == "__main__":
    print("Basic Lambda Examples:")
    basic_lambda_examples()
    print("\nLambda with Built-in Functions:")
    lambda_with_builtin_functions()
    print("\nLambda in Sorting:")
    lambda_in_sorting()
    print("\nLambda List Operations:")
    lambda_list_operations()
    print("\nLambda as Arguments:")
    lambda_as_arguments()
    print("\nFunctional Programming with Lambda:")
    functional_programming_examples()
    print("\nMap Examples:")
    map_examples()
    print("\nFilter Examples:")
    filter_examples()
    print("\nReduce Examples:")
    reduce_examples()
    print("\nPractical Examples:")
    practical_examples()
    print("\nMemory Efficiency Examples:")
    memory_efficiency_examples()
    print("\nIterator Processing:")
    explain_iterator_processing()
    print("\nIterator Limitation:")
    demonstrate_iterator_limitation()
