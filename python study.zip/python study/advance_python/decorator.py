def capitalize(func):
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)  # Call the original function with the arguments
        if isinstance(result, str):  # If the result is a string
            return result.upper()  # Capitalize the result
        return result  # If it's not a string, return the result as is
    return wrapper

@capitalize
def greet(arg):
    print(arg)
    return arg  # Return the argument so it can be manipulated in the decorator

print(greet("pooja"))  # Output: Pooja
