"""
Higher Order Functions in Python

A higher-order function is a function that either:
1. Takes one or more functions as arguments
2. Returns a function as its result
3. Or both

They are used for:
- Function composition
- Abstraction
- Code reusability
- Functional programming patterns
"""

# 1. Function as an argument
def apply_operation(func, x, y):
    """Higher-order function that takes a function as an argument"""
    return func(x, y)

def add(x, y):
    return x + y

def multiply(x, y):
    return x * y

# Example usage of function as argument
def demonstrate_function_as_argument():
    print("1. Function as Argument Example:")
    result1 = apply_operation(add, 5, 3)      # Passes add function
    result2 = apply_operation(multiply, 5, 3)  # Passes multiply function
    print(f"   Apply add: 5 + 3 = {result1}")
    print(f"   Apply multiply: 5 * 3 = {result2}")

# 2. Function returning another function
def create_multiplier(factor):
    """Higher-order function that returns a function"""
    def multiplier(x):
        return x * factor
    return multiplier

# Example usage of function returning function
def demonstrate_function_return():
    print("\n2. Function Returning Function Example:")
    double = create_multiplier(2)    # Creates a function that doubles
    triple = create_multiplier(3)    # Creates a function that triples
    
    print(f"   Double 5: {double(5)}")
    print(f"   Triple 5: {triple(5)}")

# 3. Function decorator (both takes and returns a function)
def uppercase_decorator(func):
    """Higher-order function that modifies another function"""
    def wrapper():
        original_result = func()
        return original_result.upper()
    return wrapper

@uppercase_decorator
def greet():
    return "hello, world!"

# 4. Practical example with built-in higher-order functions
def demonstrate_builtin_higher_order():
    print("\n3. Built-in Higher-Order Functions Example:")
    
    # map - applies function to every item
    numbers = [1, 2, 3, 4, 5]
    squared = list(map(lambda x: x**2, numbers))
    print(f"   Map (square): {squared}")
    
    # filter - filters items based on function
    even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
    print(f"   Filter (even): {even_numbers}")
    
    # reduce - reduces sequence to single value
    from functools import reduce
    sum_all = reduce(lambda x, y: x + y, numbers)
    print(f"   Reduce (sum): {sum_all}")

if __name__ == "__main__":
    # Run all demonstrations
    demonstrate_function_as_argument()
    demonstrate_function_return()
    print("\n3. Decorator Example:")
    print(f"   {greet()}")
    demonstrate_builtin_higher_order()

"""
Key Benefits of Higher-Order Functions:
1. Abstraction: Hide implementation details
2. Reusability: Create generic operations that work with different functions
3. Composition: Combine simple functions to create complex ones
4. Flexibility: Change behavior by passing different functions
"""
