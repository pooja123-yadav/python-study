"""
Multithreading and Multiprocessing in Python

Key Differences:
- Threads share memory space, processes have separate memory
- Threads are lightweight, processes are heavyweight
- Threads are limited by GIL, processes are not
- Threads are good for IO-bound tasks, processes for CPU-bound tasks
"""

import threading
import multiprocessing
import time
import queue
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import requests
import asyncio
import aiohttp  # You'll need to install this: pip install aiohttp

# =============== TRADITIONAL THREADING APPROACH ===============
class TraditionalThread(threading.Thread):
    """Traditional way of creating threads by subclassing Thread"""
    
    def __init__(self, name):
        super().__init__()
        self.name = name
    
    def run(self):
        print(f"Thread {self.name} starting")
        time.sleep(2)
        print(f"Thread {self.name} finished")

def demonstrate_traditional_threading():
    """Shows the traditional way of using threads"""
    print("\n=== Traditional Threading ===")
    threads = [TraditionalThread(f"Thread-{i}") for i in range(3)]
    
    # Start all threads
    for thread in threads:
        thread.start()
    
    # Wait for all threads to complete
    for thread in threads:
        thread.join()

# =============== MODERN THREADING APPROACH ===============
def demonstrate_modern_threading():
    """Shows the modern way of using threads with ThreadPoolExecutor"""
    print("\n=== Modern Threading (ThreadPoolExecutor) ===")
    
    def worker(name):
        print(f"Thread {name} starting")
        time.sleep(2)
        return f"Thread {name} finished"
    
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(worker, f"Thread-{i}") for i in range(3)]
        for future in futures:
            print(future.result())

# =============== TRADITIONAL MULTIPROCESSING APPROACH ===============
class TraditionalProcess(multiprocessing.Process):
    """Traditional way of creating processes by subclassing Process"""
    
    def __init__(self, name):
        super().__init__()
        self.name = name
    
    def run(self):
        print(f"Process {self.name} starting")
        time.sleep(2)
        print(f"Process {self.name} finished")

def demonstrate_traditional_multiprocessing():
    """Shows the traditional way of using processes"""
    print("\n=== Traditional Multiprocessing ===")
    processes = [TraditionalProcess(f"Process-{i}") for i in range(3)]
    
    # Start all processes
    for process in processes:
        process.start()
    
    # Wait for all processes to complete
    for process in processes:
        process.join()

# =============== MODERN MULTIPROCESSING APPROACH ===============
def demonstrate_modern_multiprocessing():
    """Shows the modern way of using processes with ProcessPoolExecutor"""
    print("\n=== Modern Multiprocessing (ProcessPoolExecutor) ===")
    
    def worker(name):
        print(f"Process {name} starting")
        time.sleep(2)
        return f"Process {name} finished"
    
    with ProcessPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(worker, f"Process-{i}") for i in range(3)]
        for future in futures:
            print(future.result())

# =============== PRACTICAL EXAMPLES ===============

# IO-Bound Example (Using Threading)
def io_bound_example():
    """Demonstrates threading for IO-bound tasks (web requests)"""
    print("\n=== IO-Bound Task Example (Threading) ===")
    
    def fetch_url(url):
        return requests.get(url).status_code
    
    urls = ["http://python.org", "http://google.com", "http://github.com"]
    
    # Using modern threading approach
    start = time.time()
    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(fetch_url, urls))
    print(f"Threading time: {time.time() - start:.2f} seconds")
    print(f"Status codes: {results}")

# CPU-Bound Example (Using Multiprocessing)
def cpu_bound_example():
    """Demonstrates multiprocessing for CPU-bound tasks"""
    print("\n=== CPU-Bound Task Example (Multiprocessing) ===")
    
    def complex_calculation(n):
        return sum(i * i for i in range(n))
    
    numbers = [10**7, 10**7, 10**7]
    
    # Using modern multiprocessing approach
    start = time.time()
    with ProcessPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(complex_calculation, numbers))
    print(f"Multiprocessing time: {time.time() - start:.2f} seconds")

# =============== WHEN TO USE WHAT ===============
"""
Use Threading When:
1. IO-bound tasks (file operations, network requests)
2. GUI applications
3. Tasks that spend time waiting
4. Need to share memory between tasks

Use Multiprocessing When:
1. CPU-bound tasks (complex calculations)
2. Need to bypass GIL
3. Parallel processing on multiple cores
4. Independent tasks with no shared memory needs
"""

# =============== MODERN BEST PRACTICES ===============
def demonstrate_best_practices():
    """Shows modern best practices for concurrent programming"""
    
    # 1. Using context managers
    with ThreadPoolExecutor() as executor:
        # Automatically handles cleanup
        pass
    
    # 2. Using futures for better control
    with ProcessPoolExecutor() as executor:
        future = executor.submit(pow, 2, 3)
        print(f"Result: {future.result()}")
    
    # 3. Combining multiple tasks
    with ThreadPoolExecutor() as executor:
        futures = [
            executor.submit(time.sleep, 1),
            executor.submit(time.sleep, 2)
        ]
        # Wait for all tasks to complete
        for future in futures:
            future.result()

# =============== ASYNC/AWAIT APPROACH ===============
async def fetch_url_async(url):
    """Asynchronous function to fetch URL"""
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

async def main_async():
    """Main async function demonstrating when to use async/await"""
    print("\n=== Async/Await Example ===")
    urls = [
        "http://python.org",
        "http://google.com",
        "http://github.com"
    ]
    
    # Create tasks for all URLs
    tasks = [fetch_url_async(url) for url in urls]
    
    # Wait for all tasks to complete
    start = time.time()
    results = await asyncio.gather(*tasks)
    print(f"Async time: {time.time() - start:.2f} seconds")

"""
When to Use Async/Await:

1. IO-Bound Operations with Many Concurrent Tasks:
   - Multiple HTTP requests
   - Database operations
   - File operations
   - Network operations

2. Specific Use Cases:
   - Web servers handling many concurrent connections
   - API services with many simultaneous requests
   - Web scraping multiple pages
   - Real-time chat applications
   - Microservices communication

3. Advantages over Threading:
   - No GIL limitations
   - No thread switching overhead
   - More predictable behavior
   - Better control over concurrency
   - Lower memory overhead

4. When NOT to Use:
   - CPU-bound tasks (use multiprocessing instead)
   - Simple sequential tasks
   - When code needs to be thread-safe
   - When dealing with blocking libraries
"""

if __name__ == "__main__":
    # Traditional approaches
    demonstrate_traditional_threading()
    demonstrate_traditional_multiprocessing()
    
    # Modern approaches
    demonstrate_modern_threading()
    demonstrate_modern_multiprocessing()
    
    # Practical examples
    try:
        io_bound_example()
    except requests.exceptions.RequestException:
        print("Network error in IO-bound example")
    
    cpu_bound_example()
    
    # Best practices
    demonstrate_best_practices()
    
    # Run async example
    try:
        asyncio.run(main_async())
    except Exception as e:
        print(f"Async example error: {e}")
