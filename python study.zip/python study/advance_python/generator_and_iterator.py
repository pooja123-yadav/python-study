"""
In Python, both generators and iterators are used to iterate over a sequence of data, but they have different 
characteristics and use cases.

Iterators
Definition: An iterator is an object that implements the iterator protocol, which consists of the methods __iter__() and __next__().
Usage: You can obtain an iterator from any iterable object (like lists, tuples, etc.) using the iter() function. You then use the next() function to iterate through the elements.
State: Iterators maintain their state, meaning they remember where they are in the sequence.
Exhaustion: Once an iterator is exhausted (i.e., all elements have been iterated over), it cannot be reset or reused. You need to create a new iterator to iterate over the sequence again.

Generators
Definition: Generators are a special type of iterator, created using functions with the yield statement.
They allow you to declare a function that behaves like an iterator.

Usage: Generators are defined like regular functions but use yield to return data. Each call to yield pauses the function, saving its state for resumption.
Memory Efficiency: Generators are more memory efficient than lists because they yield items one at a time and do not store the entire sequence in memory.
Infinite Sequences: Generators are ideal for representing infinite sequences, as they generate items on-the-fly.

Differences
1. Creation:
Iterators are created from iterable objects using the iter() function.
Generators are created using functions with yield statements.
Memory Usage:
Iterators can be memory-intensive if the iterable is large, as they may require the entire iterable to be stored in memory.
Generators are more memory-efficient as they generate items on-the-fly.
State Management:
Both maintain state, but generators automatically handle the state between yield calls.
Reusability:
Once exhausted, both need to be recreated to iterate again.

When to Use
Iterators: Use when we need to iterate over an existing iterable object and don't need the memory efficiency of generators.
Generators: Use when we need to generate a sequence of values on-the-fly, especially when dealing with large data sets or infinite sequences, to save memory.
In summary, use generators for lazy evaluation and memory efficiency, and iterators when you need to work with existing iterable objects.


iterators and generators are both tools for handling sequences in Python, 
but they serve different purposes. An iterator is a class-based approach that 
requires implementing __iter__ and __next__ methods, storing its state in 
instance variables, making it suitable for complex state management and object-oriented designs.

On the other hand, a generator is a function-based approach using the yield keyword, 
 where Python automatically manages the state between calls, 
 making it more memory-efficient as it generates values on-the-fly without 
 storing the entire sequence in memory. While iterators are like warehouses that store 
 and manage their complete state, generators are like factories that produce values only when needed.
  
Iterators are preferred when you need more control and complex state management,
 while generators are better for memory efficiency and simple sequential processing,
especially when dealing with large datasets or infinite sequences.
 Both can iterate over sequences, but generators offer a more concise and 
 memory-efficient solution for most simple iteration needs.
"""

class NumberIterator:
    """
    An iterator example that generates numbers up to a specified limit.
    
    Demonstrates the classic iterator pattern requiring __iter__ and __next__ methods.
    
    Attributes:
        limit (int): The maximum number to generate
        counter (int): The current number in the sequence
    
    Example:
        >>> iterator = NumberIterator(3)
        >>> list(iterator)
        [1, 2, 3]
    """
    
    def __init__(self, limit):
        """Initialize the iterator with a limit."""
        self.limit = limit
        self.counter = 0
    
    def __iter__(self):
        """Return the iterator object itself."""
        return self
    
    def __next__(self):
        """Return the next value in the sequence."""
        if self.counter >= self.limit:
            raise StopIteration
        self.counter += 1
        return self.counter

def number_generator(limit):
    """
    A generator function that yields numbers up to a specified limit.
    
    Demonstrates the simplicity of generator implementation compared to iterators.
    
    Args:
        limit (int): The maximum number to generate
    
    Yields:
        int: The next number in the sequence
    
    Example:
        >>> gen = number_generator(3)
        >>> list(gen)
        [1, 2, 3]
    """
    counter = 0
    while counter < limit:
        counter += 1
        yield counter

def demonstrate_memory_usage():
    """
    Demonstrates the memory usage differences between iterators and generators.
    
    Shows practical examples of both approaches and their memory implications.
    Includes examples of creating large sequences to illustrate memory efficiency.
    """
    # Using Iterator
    print("=== Iterator Example ===")
    iterator = NumberIterator(5)
    for num in iterator:
        print(f"Iterator value: {num}")

    # Using Generator
    print("\n=== Generator Example ===")
    generator = number_generator(5)
    for num in generator:
        print(f"Generator value: {num}")

    # Memory comparison example
    # Iterator - stores all values in memory
    large_list = [x for x in range(1000000)]  # Creates list in memory
    
    # Generator - generates values on the fly
    large_gen = (x for x in range(1000000))   # Creates generator object

class FileIterator:
    """
    An iterator class for reading files line by line.
    
    Demonstrates a practical use case for iterators when dealing with file operations.
    Shows how iterators can manage resources and complex state.
    
    Attributes:
        filename (str): Path to the file to be read
        file (file object): The file object being read
    
    Example:
        >>> for line in FileIterator('example.txt'):
        ...     print(line)
    """
    
    def __init__(self, filename):
        """Initialize the file iterator with a filename."""
        self.filename = filename
        self.file = None
    
    def __iter__(self):
        """Open the file and return the iterator object."""
        self.file = open(self.filename, 'r')
        return self
    
    def __next__(self):
        """Read and return the next line from the file."""
        line = self.file.readline()
        if not line:
            self.file.close()
            raise StopIteration
        return line.strip()

def file_generator(filename):
    """
    A generator function for reading files line by line.
    
    Demonstrates a more concise and memory-efficient approach to file reading
    compared to the iterator version. Uses context manager for proper resource handling.
    
    Args:
        filename (str): Path to the file to be read
    
    Yields:
        str: Each line from the file, stripped of leading/trailing whitespace
    
    Example:
        >>> for line in file_generator('example.txt'):
        ...     print(line)
    """
    with open(filename, 'r') as file:
        for line in file:
            yield line.strip()

# Iterator approach - maintains entire state in memory
class RangeIterator:
    def __init__(self, start, end):
        self.current = start    # Stores state as instance variable
        self.end = end         # Stores end value in memory
        
    def __iter__(self):
        return self
        
    def __next__(self):
        if self.current >= self.end:
            raise StopIteration
        value = self.current
        self.current += 1
        return value

# Generator approach - state is managed by Python's runtime
def range_generator(start, end):
    current = start    # Local variable, exists only during function execution
    while current < end:
        yield current  # Python's runtime remembers the state
        current += 1   # Next time yield is called, execution continues here
    """
    The key differences are:
        Iterator stores its state (current, end) as instance variables in memory throughout its lifetime
        Generator's state is managed by Python's runtime - variables only exist during execution and are "frozen" between yields
        Iterator needs to maintain all the logic and state management explicitly
        Generator lets Python handle the state management, making it more memory efficient
        While both generate values on demand with next(), the way they store and manage state is different.
    """

# Example using Iterator
class TenNumbersIterator:
    def __init__(self):
        self.num = 0
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.num >= 10:
            raise StopIteration
        self.num += 1
        return self.num

# Example using Generator
def ten_numbers_generator():
    for num in range(1, 11):
        yield num

# Usage example
def demonstrate_ten_numbers():
    print("Using Iterator:")
    iterator = TenNumbersIterator()
    for num in iterator:
        print(num, end=" ")
    
    print("\n\nUsing Generator:")
    generator = ten_numbers_generator()
    for num in generator:
        print(num, end=" ")
    print()

if __name__ == "__main__":
    demonstrate_ten_numbers()
