"""
What is polymorphism?
Polymorphism is the ability of an object to take on many forms. In object-oriented programming,
polymorphism allows you to 

what is the different types of polymorphism?
1. Compile-time polymorphism (method overloading)
2. Runtime polymorphism (method overriding)

Example of polymorphism:
    operator overloading
    method overloading
    method overriding

polymorphism in built-in functions:
    len()
    print()
    append()
"""
