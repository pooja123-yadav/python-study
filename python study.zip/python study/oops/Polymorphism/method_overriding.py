"""
Method Overriding: When a child class provides its own implementation of a method that is already defined in its parent class.
This is a fundamental concept in inheritance and polymorphism.
what is polymorphism?
    Polymorphism is the ability of an object to take on many forms. In object-oriented programming, 
    polymorphism allows you to define a single interface or method in a base class and have 
    multiple derived classes implement that method.
"""

class Parent:
    def greet(self, name):
        return f"Hello, {name}!"

class Child(Parent):
    # Overriding with different number of parameters
    def greet(self, first_name, last_name=""):  # Added an optional parameter
        if last_name:
            return f"Hi, {first_name} {last_name}!"
        return f"Hi, {first_name}!"

# Testing
def test_greetings():
    parent = Parent()
    child = Child()
    
    print("\nParent class:")
    print(parent.greet("John"))
    
    print("\nChild class:")
    print(child.greet("John"))                # Works with one argument
    print(child.greet("John", "Doe"))         # Works with two arguments

"""
Liskov Substitution Principle (LSP):
- Objects of a superclass should be replaceable with objects of its subclasses without breaking the program
- Subclass should extend functionality, not reduce it
"""

# ======= BAD EXAMPLE (Violating LSP) =======
class Rectangle:
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def set_width(self, width):
        self.width = width

    def set_height(self, height):
        self.height = height

    def get_area(self):
        return self.width * self.height

class Square(Rectangle):  # VIOLATION: Square changes behavior of parent methods
    def set_width(self, width):
        self.width = width
        self.height = width  # Violates LSP by changing both dimensions

    def set_height(self, height):
        self.width = height  # Violates LSP by changing both dimensions
        self.height = height

# This function will work unexpectedly with Square
def process_rectangle(rectangle: Rectangle):
    rectangle.set_width(5)
    rectangle.set_height(4)
    area = rectangle.get_area()
    assert area == 20, f"Expected area 20, but got {area}"  # Will fail for Square!

# ======= GOOD EXAMPLE (Following LSP) =======
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def get_area(self):
        pass

class GoodRectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def get_area(self):
        return self.width * self.height

class GoodSquare(Shape):
    def __init__(self, side):
        self.side = side

    def get_area(self):
        return self.side * self.side

# This function works correctly with any Shape
def print_area(shape: Shape):
    print(f"Area: {shape.get_area()}")

# Testing both examples
def test_lsp():
    print("\nTesting LSP Violation:")
    try:
        rect = Rectangle(5, 5)
        square = Square(5, 5)
        
        process_rectangle(rect)    # Works fine
        process_rectangle(square)  # Will fail!
    except AssertionError as e:
        print(f"LSP Violation Error: {e}")

    print("\nTesting LSP Compliance:")
    good_rect = GoodRectangle(5, 4)
    good_square = GoodSquare(5)
    
    print("Rectangle:", end=" ")
    print_area(good_rect)     # Works as expected
    print("Square:", end=" ")
    print_area(good_square)   # Works as expected

if __name__ == "__main__":
    test_greetings()
    test_lsp()