"""
Method Overloading: Having multiple methods with the same name but different parameters.
Python doesn't support traditional method overloading, but we can achieve similar functionality in 3 ways:
1. Default Arguments
2. Variable-length Arguments
3. Multiple Dispatch (using functools.singledispatch)
"""

# 1. Using Default Arguments
class Calculator:
    # Function that can handle different number of arguments
    def calculate(self, operation="add", *args, **kwargs):
        """
        operation: type of operation (add, multiply, etc.)
        *args: variable number of positional arguments
        **kwargs: variable number of keyword arguments
        """
        print(f"\nPositional args (args): {args}")
        print(f"Keyword args (kwargs): {kwargs}")
        
        if len(args) == 0 and len(kwargs) == 0:
            return 0
            
        if operation == "add":
            # Sum both positional and keyword arguments
            return sum(args) + sum(kwargs.values())
        elif operation == "multiply":
            result = 1
            for num in args:
                result *= num
            for num in kwargs.values():
                result *= num
            return result

# 2. Using Variable-length Arguments
class AdvancedCalculator:
    def add(self, *args):
        print(args)
        return sum(args)

# 3. Using Type Checking
class TypeCalculator:
    def add(self, a, b=None):
        if b is None:  # If only one argument is passed
            if isinstance(a, (list, tuple)):
                return sum(a)
            return a
        return a + b

# Let's test all approaches
def test_overloading():
    # Test Default Arguments
    calc = Calculator()
    print("\nTesting Default Arguments:")
    print("Two numbers:", calc.calculate("add", 1, 2))        # Uses a, b
    print("Three numbers:", calc.calculate("add", 1, 2, 3))   # Uses a, b, c
    print("One number:", calc.calculate("add", 1))            # Uses only a

    # Test Variable-length Arguments
    adv_calc = AdvancedCalculator()
    print("\nTesting Variable-length Arguments:")
    print("Two numbers:", adv_calc.add(1, 2))
    print("Four numbers:", adv_calc.add(1, 2, 3, 4))
    print("Five numbers:", adv_calc.add(1, 2, 3, 4, 5))

    # Test Type Checking
    type_calc = TypeCalculator()
    print("\nTesting Type Checking:")
    print("Two numbers:", type_calc.add(10, 20))
    print("List of numbers:", type_calc.add([1, 2, 3, 4]))
    print("Single number:", type_calc.add(100))

# Run the tests
if __name__ == "__main__":
    test_overloading()
