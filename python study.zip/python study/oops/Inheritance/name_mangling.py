class Student:
    def __init__(self):
        self.__name = "Alice"    # Python secretly changes this to _Student__name
        self._age = 20           # This stays as _age (no mangling)
        self.school = "ABC"      # This stays as school (no mangling)

student = Student()
print(student.__name)        # Error! Can't find __name
print(student._Student__name)  # Works! This is the secret nickname
print(student._age)          # Works! No nickname needed
print(student.school)        # Works! No nickname needed



""""
Name mangling is like giving a secret nickname to class attributes that start with double underscores (__).
Think of it like this:
When you use __ (double underscore), Python gives it a special nickname: _ClassName__attribute
This is just to prevent naming conflicts, not for real privacy
It's like putting your name on your lunch box so it doesn't get mixed up with someone else's
That's it! Name mangling is just Python's way of renaming things to avoid confusion, especially when working with inherited classes
"""