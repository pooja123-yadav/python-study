from abc import ABC, abstractmethod

class NotificationManager(ABC):
    """Notification manager class"""

    def __init__(self):
        pass
    
    @abstractmethod
    def send(self, message):
        pass

class EmailNotification(NotificationManager):
    
    """EMail Notification class"""

    def __init__(self, email):
        self.sendgrid = SendGridAPIClient(api_key=os.environ.get('SENDGRID_API_KEY'))
        self.email = email

    def send(self, message: str):
        print(f"send email {message}")

class SMSNotification(NotificationManager):
    
    """SMS Notification class"""

    def __init__(self, number):
         self.API_KEY = os.environ.get('TWILIO_API_KEY')
        self.number = number

    def send(self, message: str):
        print(f"send sms {message}")

class PushNotification(NotificationManager):
    
    """Push Notification class"""

    def __init__(self, device_id):
        self.fcm = os.environ.get('FCM_API_KEY')
        self.device_id = device_id

    def send(self, message: str):
        print(f"send push {message}")

class User:
    def __init__(self, name: str):
        self.name = name
        self.channels = list()

    def add_notification_channel(self, channel: NotificationManager):
        self.channels.append(channel)

    def send_notification(self, message:str):
        if self.channels:
            for channel in self.channels:
                channel.send(message)


if __name__ == "__main__":
    user = User("Pooja")
    user.add_notification_channel(EmailNotification("pooja@gmail.com"))
    user.add_notification_channel(SMSNotification("9873763514"))
    user.add_notification_channel(PushNotification("pooja mobule app"))
    user.send_notification("you have a message")