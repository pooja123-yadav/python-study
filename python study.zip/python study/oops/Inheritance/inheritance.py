"""
Types of inheritance in python
single inheritance
multiple inheritance
multilevel inheritance
Hierarchical Inheritance: 
Hybrid Inheritance: 


"""


# Base class
class Parent:
    def func1(self):
        print(self)
        print("This function is in par ent class.")
 
# Derived class
class Child(Parent):
    def __init__(self):
        Parent.func1(self)
    def func2(self):
        print("This function is in child class.")

# Driver's code
object = Child()
object.func1()
object.func2()