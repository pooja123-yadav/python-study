"""
Static Method:
- Decorated with @staticmethod
- Takes no special first parameter
- Cannot access or modify class state
- Cannot access class variables
- Utility functions that belong to class namespace
"""

class MathOperations:
    PI = 3.14159
    
    def __init__(self, value):
        self.value = value
    
    @staticmethod
    def add(x, y):
        # Cannot access class or instance variables
        return x + y
    
    @staticmethod
    def is_positive(number):
        # Utility function that doesn't need class state
        return number > 0
    
    @staticmethod
    def calculate_area(radius):
        # Even though PI is a class variable, static method uses hardcoded value
        return 3.14159 * radius * radius

# Using static methods
print("\nTesting Static Methods:")
print(f"Add numbers: {MathOperations.add(5, 3)}")
print(f"Is positive: {MathOperations.is_positive(10)}")
print(f"Circle area: {MathOperations.calculate_area(5)}")

"""
Key Differences:

1. Parameter:
   - Class Method: Takes 'cls' as first parameter
   - Static Method: Takes no special first parameter

2. Class State Access:
   - Class Method: Can access and modify class state
   - Static Method: Cannot access class state

3. Instance Creation:
   - Class Method: Can create class instances using 'cls'
   - Static Method: Cannot create class instances

4. Inheritance:
   - Class Method: Works with inheritance (cls refers to actual class)
   - Static Method: Doesn't depend on inheritance

5. Use Cases:
   - Class Method: When you need to do something with the class
   - Static Method: When you need a utility function related to class

6. Class Variable Access:
   - Class Method: Can access and modify class variables
   - Static Method: Cannot access class variables directly
"""
