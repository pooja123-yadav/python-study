class Employee:
    """give an example for inbuilt class method"""
    name = 'John'

print(Employee.__dict__)
print(Employee.__doc__)
print(Employee.__name__)
print(Employee.__module__)

