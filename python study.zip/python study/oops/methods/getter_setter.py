"""
Comparing Traditional Getters/Setters with Property Decorators
"""

# Traditional Way with Getters and Setters
class StudentTraditional:
    def __init__(self, name, age):
        self._name = name
        self._age = age
    
    # Traditional getters and setters
    def get_name(self):
        return self._name
    
    def set_name(self, name):
        if isinstance(name, str) and name.strip():
            self._name = name
        else:
            raise ValueError("Name must be a non-empty string")
    
    def get_age(self):
        return self._age
    
    def set_age(self, age):
        if isinstance(age, int) and 0 <= age <= 120:
            self._age = age
        else:
            raise ValueError("Age must be between 0 and 120")

# Modern Way with Properties
class StudentProperty:
    def __init__(self, name, age):
        self._name = name
        self._age = age
    
    # Property for name
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        if isinstance(value, str) and value.strip():
            self._name = value
        else:
            raise ValueError("Name must be a non-empty string")
    
    # Property for age
    @property
    def age(self):
        return self._age
    
    @age.setter
    def age(self, value):
        if isinstance(value, int) and 0 <= value <= 120:
            self._age = value
        else:
            raise ValueError("Age must be between 0 and 120")

def test_both_approaches():
    # Test Traditional Way
    print("\nTesting Traditional Getters/Setters:")
    student1 = StudentTraditional("John", 20)
    print(f"Name: {student1.get_name()}")
    student1.set_name("Johnny")
    print(f"Updated name: {student1.get_name()}")
    
    # Test Property Way
    print("\nTesting Property Decorators:")
    student2 = StudentProperty("Alice", 22)
    print(f"Name: {student2.name}")  # Looks like attribute access
    student2.name = "Alicia"         # Looks like attribute assignment
    print(f"Updated name: {student2.name}")
    
    # Test Validation
    print("\nTesting Validation:")
    try:
        student1.set_age(-5)  # Traditional way
    except ValueError as e:
        print(f"Traditional validation: {e}")
    
    try:
        student2.age = -5     # Property way
    except ValueError as e:
        print(f"Property validation: {e}")

if __name__ == "__main__":
    test_both_approaches()

"""
Key Differences:

1. Syntax:
   Traditional: student.get_name(), student.set_name("John")
   Property: student.name, student.name = "John"

2. Usage:
   Traditional: Explicit method calls
   Property: Looks like regular attribute access

3. Benefits of Property:
   - More pythonic syntax
   - Better encapsulation
   - Backward compatibility
   - Can start with simple attributes and add properties later

4. When to Use Each:
   Traditional:
   - Working with languages that expect getters/setters
   - Following specific framework conventions
   
   Property:
   - Modern Python code
   - Clean, pythonic interface
   - Need to add validation later without changing interface
"""
