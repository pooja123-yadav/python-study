"""give an example for inbuilt class method"""

class Employee:
    """give an example for inbuilt class method"""

    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary

print(Employee.__doc__)
# print(Employee.__dict__)
# print(Employee.__name__)
# print(Employee.__module__)

setattr(Employee, 'name', 'John')
print(Employee.name)

getattr(Employee, 'name')

# delattr(Employee, 'name')
# print(Employee.name)

print(hasattr(Employee, 'name'))
