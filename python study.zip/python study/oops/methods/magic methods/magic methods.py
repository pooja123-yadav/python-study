"""
Magic Methods (Dunder Methods):
- Special methods in Python that start and end with double underscores (__method__)
- They allow classes to emulate built-in behavior
- They're called automatically by Python in specific circumstances
"""

class Person:
    def __new__(cls, *args, **kwargs):
        """
        Called when creating a new instance (before __init__)
        - First method called in instance creation
        - Responsible for returning the new instance
        - Rarely overridden unless you need to control instance creation
        """
        print("1. __new__: Creating instance")
        return super().__new__(cls)

    def __init__(self, name, age):
        """
        Called after __new__ to initialize the instance
        - Sets up the instance with attributes
        - Cannot return a value
        - Most common constructor method
        """
        print("2. __init__: Initializing instance")
        self.name = name
        self.age = age

    def __call__(self, *args, **kwargs):
        """
        Makes instance callable like a function
        person() will call this method
        """
        print("3. __call__: Instance is being called like a function")
        return f"You called {self.name}!"

    def __str__(self):
        """
        Defines string representation for humans
        Called by str() and print()
        """
        return f"Person named {self.name}, aged {self.age}"

    def __repr__(self):
        """
        Defines string representation for developers
        Should ideally be detailed enough to recreate the object
        """
        return f"Person(name='{self.name}', age={self.age})"

    def __len__(self):
        """
        Makes object work with len() function
        Must return an integer
        """
        return self.age  # Just an example, returns age as length

def test_magic_methods():
    # Creating instance (calls __new__ and __init__)
    print("\nCreating instance:")
    person = Person("Alice", 30)

    # Testing __str__ and __repr__
    print("\nString representations:")
    print(f"str(): {str(person)}")    # Uses __str__
    print(f"repr(): {repr(person)}")  # Uses __repr__

    # Testing __call__
    print("\nCalling instance:")
    result = person()                  # Uses __call__
    print(result)

    # Testing __len__
    print("\nLength of instance:")
    print(f"len(): {len(person)}")    # Uses __len__

if __name__ == "__main__":
    test_magic_methods()

"""
Key Differences:

1. __new__ vs __init__:
   - __new__: Creates and returns the instance
   - __init__: Initializes the created instance
   - Order: __new__ is called first, then __init__

2. __str__ vs __repr__:
   - __str__: Human-readable string, for end users
   - __repr__: Detailed string, for developers
   - If __str__ is missing, __repr__ is used as fallback

3. __call__ vs regular methods:
   - __call__: Makes instance callable like a function
   - Regular methods: Need explicit method name to call
"""
