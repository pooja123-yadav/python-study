class Employee:

    def __init__(self, first_name, last_name, salary):
        self._first_name = first_name
        self._last_name = last_name
        self._salary = salary

    @property
    def full_name(self):
        """Gets the full name"""
        return f"{self._first_name} {self._last_name}"

    @property
    def salary(self):
        return self._salary
    
    @salary.setter
    def salary(self, value):
        """Sets the salary with validation"""
        if value < 0:
            raise ValueError("Salary cannot be negative")
        self._salary = value
    
    @salary.deleter
    def salary(self):
        """Deletes the salary"""
        print(f"Deleting salary for {self.full_name}")
        del self._salary

emp = Employee("pooja", "yadav", 50000)
print(emp.salary)
emp.salary = 100000
print(emp.salary)
del emp.salary
print(emp.salary)
    


