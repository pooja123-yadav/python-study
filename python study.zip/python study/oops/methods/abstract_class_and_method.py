"""
Abstract Class and Methods:
- Abstract class is a class that contains one or more abstract methods
- Abstract method is a method that has declaration but no implementation
- Abstract classes cannot be instantiated directly
- Child classes must implement all abstract methods
"""

from abc import ABC, abstractmethod

# Abstract Base Class
class Shape(ABC):
    def __init__(self, color):
        self.color = color
    
    @abstractmethod
    def area(self):
        """Abstract method that must be implemented by all child classes"""
        pass
    
    @abstractmethod
    def perimeter(self):
        """Another abstract method"""
        pass
    
    def get_color(self):
        """Regular (non-abstract) method"""
        return f"Color is {self.color}"

# Concrete Classes implementing Shape
class Rectangle(Shape):
    def __init__(self, color, length, width):
        super().__init__(color)
        self.length = length
        self.width = width
    
    def area(self):  # Must implement this
        return self.length * self.width
    
    def perimeter(self):  # Must implement this
        return 2 * (self.length + self.width)

class Circle(Shape):
    def __init__(self, color, radius):
        super().__init__(color)
        self.radius = radius
    
    def area(self):  # Must implement this
        return 3.14 * self.radius * self.radius
    
    def perimeter(self):  # Must implement this
        return 2 * 3.14 * self.radius

def test_abstract_classes():
    # Cannot instantiate abstract class
    try:
        shape = Shape("red")  # This will raise TypeError
    except TypeError as e:
        print("\nTrying to create Shape instance:")
        print(f"Error: {e}")
    
    # Creating concrete class instances
    print("\nCreating concrete instances:")
    rectangle = Rectangle("blue", 5, 3)
    circle = Circle("red", 4)
    
    # Using the implementations
    print("\nTesting Rectangle:")
    print(f"Area: {rectangle.area()}")
    print(f"Perimeter: {rectangle.perimeter()}")
    print(rectangle.get_color())
    
    print("\nTesting Circle:")
    print(f"Area: {circle.area()}")
    print(f"Perimeter: {circle.perimeter()}")
    print(circle.get_color())

if __name__ == "__main__":
    test_abstract_classes()

"""
Key Points about Abstract Classes:

1. Purpose:
   - Define a common interface for a group of related classes
   - Enforce certain methods to be implemented
   - Share common functionality

2. Rules:
   - Cannot instantiate abstract class
   - Must implement all abstract methods in child classes
   - Can have both abstract and concrete methods

3. When to Use:
   - Need to ensure certain methods are implemented
   - Want to share common functionality
   - Have a group of related classes

4. Benefits:
   - Code organization
   - Enforced implementation
   - Shared functionality
   - Clear interface definition
"""
