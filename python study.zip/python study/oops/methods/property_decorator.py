"""
Property Decorator (@property):
- Allows you to define methods that can be accessed like attributes
- Provides a way to implement getters, setters, and deleters
- Helps in data encapsulation and validation
- Makes attribute access more controlled and pythonic
"""

class Employee:
    def __init__(self, first_name, last_name, salary):
        self._first_name = first_name
        self._last_name = last_name
        self._salary = salary
    
    # Getter property
    @property
    def full_name(self):
        """Gets the full name"""
        return f"{self._first_name} {self._last_name}"
    
    # Getter property
    @property
    def salary(self):
        """Gets the salary"""
        return self._salary
    
    # Setter property
    @salary.setter
    def salary(self, value):
        """Sets the salary with validation"""
        if value < 0:
            raise ValueError("Salary cannot be negative")
        self._salary = value
    
    # Deleter property
    @salary.deleter
    def salary(self):
        """Deletes the salary"""
        print(f"Deleting salary for {self.full_name}")
        del self._salary
    
    # Property using property()
    def get_email(self):
        return f"{self._first_name.lower()}.{self._last_name.lower()}@company.com"
    
    # Alternative way using property()
    email = property(get_email)

def test_properties():
    # Create an employee
    emp = Employee("John", "Doe", 50000)
    
    print("\nAccessing properties:")
    # Using property as getter
    print(f"Full Name: {emp.full_name}")  # Accessed like an attribute
    print(f"Email: {emp.email}")
    print(f"Current Salary: {emp.salary}")
    
    print("\nModifying salary:")
    # Using property as setter
    emp.salary = 60000  # Sets using property
    print(f"New Salary: {emp.salary}")
    
    print("\nTrying invalid salary:")
    # Testing validation
    try:
        emp.salary = -1000  # Will raise ValueError
    except ValueError as e:
        print(f"Error: {e}")
    
    print("\nDeleting salary:")
    # Using property as deleter
    del emp.salary  # Calls deleter
    
    try:
        print(emp.salary)  # Will raise AttributeError
    except AttributeError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_properties()

"""
Key Points about Properties:

1. Types of Property Methods:
   - getter: @property
   - setter: @name.setter
   - deleter: @name.deleter

2. Benefits:
   - Encapsulation: Hide internal implementation
   - Validation: Control attribute modification
   - Computed Attributes: Calculate values on-the-fly
   - Backward Compatibility: Can change implementation without changing interface

3. When to Use:
   - Need to validate attribute values
   - Want computed/derived attributes
   - Need to control attribute access
   - Want to make attribute read-only

The @property decorator in Python is a built-in decorator that allows you to define methods in a class 
that can be accessed like attributes. This is useful for encapsulating the internal representation of an attribute while providing a way to compute or validate its value dynamically.
How @property Works
    The @property decorator turns a method into a "getter" for a property. You can also define "setter" 
    and "deleter" methods for the property using the @property_name.setter and @property_name.deleter 
    decorators, respectively.
"""
