"""
Class Method:
- Decorated with @classmethod
- Takes 'cls' as first parameter (class reference)
- Can access and modify class state
- Can be inherited and work with inheritance
- Can access class variables and modify them
"""

class Student:
    # Class variable
    school_name = "ABC School"
    
    def __init__(self, name):
        self.name = name
    
    @classmethod
    def change_school(cls, new_school):
        # Can modify class state
        cls.school_name = new_school
        return cls.school_name
    
    @classmethod
    def create_student(cls, name):
        # Can create class instance
        print(f"Creating student instance with name: {name}")
        return cls(name)
    
    @classmethod
    def get_school_info(cls):
        # Can access class variables
        return f"School Name: {cls.school_name}"

# Using class methods
print("\nTesting Class Methods:")
print(f"Original school: {Student.school_name}")

# Change school using class method
Student.change_school("XYZ School")
print(f"New school: {Student.school_name}")

# Create instance using class method
student = Student.create_student("Alice")
print(f"Student: {student.name}, School: {student.school_name}")

s = Student("John")
print(f"Student: {s.name}, School: {s.school_name}")

"""
Inheritance behavior with Class Methods and Static Methods
"""

class Animal:
    # Class variable
    species_count = 0
    
    def __init__(self, name):
        self.name = name
        Animal.species_count += 1
    
    @classmethod
    def get_species_count(cls):  # cls will refer to the actual class that calls it
        return cls.species_count
    
    @staticmethod
    def is_mammal(species_name):  # static method remains same for all classes
        mammals = ['dog', 'cat', 'cow']
        return species_name.lower() in mammals

class Dog(Animal):
    dog_count = 0  # Dog-specific class variable
    
    def __init__(self, name):
        super().__init__(name)
        Dog.dog_count += 1
    
    @classmethod
    def get_species_count(cls):  # Override class method
        return f"Number of dogs: {cls.dog_count}"
    
    @staticmethod
    def is_mammal(species_name):  # Override static method
        return True  # All dogs are mammals

class Cat(Animal):
    cat_count = 0
    
    def __init__(self, name):
        super().__init__(name)
        Cat.cat_count += 1
    
    # Using parent's class method and static method

def test_inheritance():
    # Create instances
    dog1 = Dog("Buddy")
    dog2 = Dog("Max")
    cat1 = Cat("Whiskers")
    
    print("\nTesting Class Methods:")
    print(f"Animal count: {Animal.get_species_count()}")  # Uses Animal's method
    print(f"Dog count: {Dog.get_species_count()}")       # Uses Dog's overridden method
    print(f"Cat count: {Cat.get_species_count()}")       # Uses Animal's method
    
    print("\nTesting Static Methods:")
    print(f"Is dog a mammal (Animal): {Animal.is_mammal('dog')}")  # Uses Animal's method
    print(f"Is dog a mammal (Dog): {Dog.is_mammal('dog')}")        # Uses Dog's overridden method
    print(f"Is dog a mammal (Cat): {Cat.is_mammal('dog')}")        # Uses Animal's method
    
    # Testing with instances
    print("\nTesting with instances:")
    print(f"Dog instance method: {dog1.get_species_count()}")
    print(f"Cat instance method: {cat1.get_species_count()}")

if __name__ == "__main__":
    test_inheritance()

"""
Key Points about Inheritance:

1. Class Methods (@classmethod):
   - Can be overridden in child classes
   - 'cls' parameter refers to the actual class calling the method
   - Inherited class methods work with child class variables
   - Good for class-specific behavior

2. Static Methods (@staticmethod):
   - Can be overridden but don't know about the class
   - Same behavior regardless of which class calls them
   - No access to class or instance attributes
   - Good for utility functions

3. Inheritance Behavior:
   - Class methods maintain polymorphic behavior
   - Static methods are more like regular functions
   - Child classes can choose to override or use parent methods
"""
