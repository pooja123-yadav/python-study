"""
SOLID Principles:
1. Single Responsibility Principle (SRP)
2. Open/Closed Principle (OCP)
3. Liskov Substitution Principle (LSP)
4. Interface Segregation Principle (ISP)
5. Dependency Inversion Principle (DIP)
"""

# 1. Single Responsibility Principle (SRP)
# "A class should have only one reason to change"

# Violation of SRP
class UserBad:
    def __init__(self, name: str):
        self.name = name
    
    def get_user_data(self):
        return f"User: {self.name}"
    
    def save_to_db(self):  # Violation: Class handling both user data and database operations
        print(f"Saving {self.name} to database")
    
    def generate_report(self):  # Violation: Class also handling reporting
        print(f"Generating report for {self.name}")

# Correct SRP Implementation
class User:
    def __init__(self, name: str):
        self.name = name
    
    def get_user_data(self):
        return f"User: {self.name}"

class UserDB:
    @staticmethod
    def save(user: User):
        print(f"Saving {user.name} to database")

class UserReporter:
    @staticmethod
    def generate_report(user: User):
        print(f"Generating report for {user.name}")

# 2. Open/Closed Principle (OCP)
# "Software entities should be open for extension, but closed for modification"

# Violation of OCP
class DiscountCalculatorBad:
    def calculate_discount(self, product_type: str, price: float) -> float:
        if product_type == "electronics":
            return price * 0.9
        elif product_type == "clothing":  # Violates OCP: Need to modify existing code for new types
            return price * 0.95
        return price

# Correct OCP Implementation
from abc import ABC, abstractmethod

class DiscountStrategy(ABC):
    @abstractmethod
    def calculate_discount(self, price: float) -> float:
        pass

class ElectronicsDiscount(DiscountStrategy):
    def calculate_discount(self, price: float) -> float:
        return price * 0.9

class ClothingDiscount(DiscountStrategy):
    def calculate_discount(self, price: float) -> float:
        return price * 0.95

class DiscountCalculator:
    def calculate_discount(self, strategy: DiscountStrategy, price: float) -> float:
        return strategy.calculate_discount(price)

# 3. Liskov Substitution Principle (LSP)
# "Subtypes must be substitutable for their base types"

# Violation of LSP
class BirdBad:
    def fly(self):
        print("Flying...")

class PenguinBad(BirdBad):  # Violation: Penguin can't fly but inherits fly method
    def fly(self):
        raise Exception("Can't fly!")  # Breaks LSP

# Correct LSP Implementation
class Bird(ABC):
    @abstractmethod
    def move(self):
        pass

class FlyingBird(Bird):
    def move(self):
        print("Flying...")

class SwimmingBird(Bird):
    def move(self):
        print("Swimming...")

# 4. Interface Segregation Principle (ISP)
# "Clients should not be forced to depend on interfaces they do not use"

# Violation of ISP
class WorkerBad(ABC):
    @abstractmethod
    def work(self):
        pass
    
    @abstractmethod
    def eat(self):
        pass
    
    @abstractmethod
    def sleep(self):
        pass

# Correct ISP Implementation
class Workable(ABC):
    @abstractmethod
    def work(self):
        pass

class Eatable(ABC):
    @abstractmethod
    def eat(self):
        pass

class Sleepable(ABC):
    @abstractmethod
    def sleep(self):
        pass

class Human(Workable, Eatable, Sleepable):
    def work(self):
        print("Working...")
    
    def eat(self):
        print("Eating...")
    
    def sleep(self):
        print("Sleeping...")

# 5. Dependency Inversion Principle (DIP)
# "High-level modules should not depend on low-level modules. Both should depend on abstractions"

# Violation of DIP
class LightBulbBad:
    def turn_on(self):
        print("Light bulb turned on")
    
    def turn_off(self):
        print("Light bulb turned off")

class SwitchBad:
    def __init__(self):
        self.bulb = LightBulbBad()  # Violation: High-level module depends on low-level module
    
    def operate(self):
        # Some operation

# Correct DIP Implementation
class Switchable(ABC):
    @abstractmethod
    def turn_on(self):
        pass
    
    @abstractmethod
    def turn_off(self):
        pass

class LightBulb(Switchable):
    def turn_on(self):
        print("Light bulb turned on")
    
    def turn_off(self):
        print("Light bulb turned off")

class Fan(Switchable):
    def turn_on(self):
        print("Fan turned on")
    
    def turn_off(self):
        print("Fan turned off")

class Switch:
    def __init__(self, device: Switchable):
        self.device = device
    
    def operate(self, cmd: str):
        if cmd == "on":
            self.device.turn_on()
        elif cmd == "off":
            self.device.turn_off()

def test_solid_principles():
    # Testing SRP
    print("\nTesting Single Responsibility Principle:")
    user = User("John")
    UserDB.save(user)
    UserReporter.generate_report(user)
    
    # Testing OCP
    print("\nTesting Open/Closed Principle:")
    calculator = DiscountCalculator()
    electronics = ElectronicsDiscount()
    clothing = ClothingDiscount()
    print(f"Electronics discount: {calculator.calculate_discount(electronics, 100)}")
    print(f"Clothing discount: {calculator.calculate_discount(clothing, 100)}")
    
    # Testing LSP
    print("\nTesting Liskov Substitution Principle:")
    flying_bird = FlyingBird()
    swimming_bird = SwimmingBird()
    flying_bird.move()
    swimming_bird.move()
    
    # Testing ISP
    print("\nTesting Interface Segregation Principle:")
    human = Human()
    human.work()
    human.eat()
    human.sleep()
    
    # Testing DIP
    print("\nTesting Dependency Inversion Principle:")
    bulb = LightBulb()
    fan = Fan()
    switch = Switch(bulb)
    switch.operate("on")
    switch = Switch(fan)
    switch.operate("off")

if __name__ == "__main__":
    test_solid_principles() 