"""
Design Patterns: Reusable solutions to common problems in software design.

Main Categories:
1. Creational Patterns: How objects are created
2. Structural Patterns: How objects relate to each other
3. Behavioral Patterns: How objects communicate with each other
"""

# 1. Singleton Pattern (Creational)
class Singleton:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        self.value = "I am a singleton"

# 2. Factory Pattern (Creational)
class Animal:
    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        return "Woof!"

class Cat(Animal):
    def speak(self):
        return "Meow!"

class AnimalFactory:
    @staticmethod
    def create_animal(animal_type):
        if animal_type.lower() == "dog":
            return Dog()
        elif animal_type.lower() == "cat":
            return Cat()
        raise ValueError("Invalid animal type")

# 3. Observer Pattern (Behavioral)
class Subject:
    def __init__(self):
        self._observers = []
        self._state = None
    
    def attach(self, observer):
        self._observers.append(observer)
    
    def notify(self):
        for observer in self._observers:
            observer.update(self._state)
    
    @property
    def state(self):
        return self._state
    
    @state.setter
    def state(self, value):
        self._state = value
        self.notify()

class Observer:
    def __init__(self, name):
        self.name = name
    
    def update(self, state):
        print(f"Observer {self.name} received state: {state}")

# 4. Strategy Pattern (Behavioral)
class PaymentStrategy:
    def pay(self, amount):
        pass

class CreditCardPayment(PaymentStrategy):
    def pay(self, amount):
        return f"Paid ${amount} using Credit Card"

class PayPalPayment(PaymentStrategy):
    def pay(self, amount):
        return f"Paid ${amount} using PayPal"

class ShoppingCart:
    def __init__(self, payment_strategy: PaymentStrategy):
        self.payment_strategy = payment_strategy
    
    def checkout(self, amount):
        return self.payment_strategy.pay(amount)

def test_patterns():
    # Test Singleton
    print("\nTesting Singleton Pattern:")
    s1 = Singleton()
    s2 = Singleton()
    print(f"Are instances same? {s1 is s2}")
    
    # Test Factory
    print("\nTesting Factory Pattern:")
    factory = AnimalFactory()
    dog = factory.create_animal("dog")
    cat = factory.create_animal("cat")
    print(f"Dog says: {dog.speak()}")
    print(f"Cat says: {cat.speak()}")
    
    # Test Observer
    print("\nTesting Observer Pattern:")
    subject = Subject()
    observer1 = Observer("One")
    observer2 = Observer("Two")
    subject.attach(observer1)
    subject.attach(observer2)
    subject.state = "New State!"
    
    # Test Strategy
    print("\nTesting Strategy Pattern:")
    cart1 = ShoppingCart(CreditCardPayment())
    cart2 = ShoppingCart(PayPalPayment())
    print(cart1.checkout(100))
    print(cart2.checkout(100))

if __name__ == "__main__":
    test_patterns()

"""
Common Design Patterns:

1. Creational Patterns:
   - Singleton: Ensures a class has only one instance
   - Factory: Creates objects without specifying exact class
   - Builder: Constructs complex objects step by step
   - Prototype: Creates objects by cloning existing ones

2. Structural Patterns:
   - Adapter: Makes incompatible interfaces compatible
   - Decorator: Adds responsibilities to objects dynamically
   - Facade: Provides simplified interface to complex system
   - Composite: Treats group of objects as single object

3. Behavioral Patterns:
   - Observer: Notifies objects of state changes
   - Strategy: Defines family of interchangeable algorithms
   - Command: Encapsulates request as an object
   - Iterator: Accesses elements sequentially

When to Use:
- Singleton: Global state, shared resources
- Factory: Complex object creation
- Observer: Event handling, notifications
- Strategy: Different variations of an algorithm
""" 