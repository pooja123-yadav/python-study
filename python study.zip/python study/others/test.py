a=1000
b=2
c=3
d = 1000
x = [a,b,c]

if id(a) == id(d):
    print("same")
else:
    print("not same")